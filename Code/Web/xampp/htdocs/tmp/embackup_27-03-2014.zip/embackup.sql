#
# TABLE STRUCTURE FOR: bqueue
#

DROP TABLE IF EXISTS bqueue;

CREATE TABLE `bqueue` (
  `idBqueue` int(11) NOT NULL AUTO_INCREMENT,
  `sid` varchar(64) NOT NULL,
  `fk_idOrders` int(11) NOT NULL,
  `fk_sid` varchar(64) NOT NULL,
  `status` enum('received','inprogress','checkedout','done') NOT NULL DEFAULT 'received',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`idBqueue`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: categories
#

DROP TABLE IF EXISTS categories;

CREATE TABLE `categories` (
  `idCategories` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(45) NOT NULL,
  `description` tinytext,
  `idImage` int(11) NOT NULL DEFAULT '0',
  `extras` mediumtext,
  PRIMARY KEY (`idCategories`),
  KEY `fk_idImages` (`idImage`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='Main Courses, Appetizers etc';

INSERT INTO categories (`idCategories`, `label`, `description`, `idImage`, `extras`) VALUES (14, 'Category one', '', 0, NULL);
INSERT INTO categories (`idCategories`, `label`, `description`, `idImage`, `extras`) VALUES (12, 'Category two', 'boo', 0, NULL);
INSERT INTO categories (`idCategories`, `label`, `description`, `idImage`, `extras`) VALUES (15, 'Menu Prova Cat', '', 0, NULL);


#
# TABLE STRUCTURE FOR: config
#

DROP TABLE IF EXISTS config;

CREATE TABLE `config` (
  `device` varchar(45) NOT NULL,
  `key` varchar(45) DEFAULT NULL,
  `value` tinytext
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO config (`device`, `key`, `value`) VALUES ('server', 'mininterval', '60000');
INSERT INTO config (`device`, `key`, `value`) VALUES ('server', 'maxitems', '0');
INSERT INTO config (`device`, `key`, `value`) VALUES ('server', 'maxrounds', '0');
INSERT INTO config (`device`, `key`, `value`) VALUES ('server', 'servuilang', 'english');
INSERT INTO config (`device`, `key`, `value`) VALUES ('tablet', 'restmode', 'alacarte');
INSERT INTO config (`device`, `key`, `value`) VALUES ('tablet', 'displaymode', 'listview');
INSERT INTO config (`device`, `key`, `value`) VALUES ('tablet', 'currency', '$');
INSERT INTO config (`device`, `key`, `value`) VALUES ('tablet', 'price', '{\"adults\":\"11.27\",\"children\":\"6.49\"}');


#
# TABLE STRUCTURE FOR: images
#

DROP TABLE IF EXISTS images;

CREATE TABLE `images` (
  `idImages` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(100) NOT NULL,
  `fileName` varchar(100) NOT NULL,
  PRIMARY KEY (`idImages`),
  UNIQUE KEY `label` (`label`)
) ENGINE=MyISAM AUTO_INCREMENT=59 DEFAULT CHARSET=utf8;

INSERT INTO images (`idImages`, `label`, `fileName`) VALUES (42, 'Coke', 'coca.jpg');
INSERT INTO images (`idImages`, `label`, `fileName`) VALUES (41, 'Pesce2', 'img.png');
INSERT INTO images (`idImages`, `label`, `fileName`) VALUES (40, 'Pesce1', '54-2-zoom-2-il_ristorante_5.jpg');
INSERT INTO images (`idImages`, `label`, `fileName`) VALUES (39, 'wine', 'wine2.png');
INSERT INTO images (`idImages`, `label`, `fileName`) VALUES (51, 'food', 'food_(800x600).jpg');
INSERT INTO images (`idImages`, `label`, `fileName`) VALUES (52, 'logo', 'logo.png');
INSERT INTO images (`idImages`, `label`, `fileName`) VALUES (53, 'Salad', 'custom_buffet_italian_salad_m1.jpg');
INSERT INTO images (`idImages`, `label`, `fileName`) VALUES (54, 'Chicken Club Sandwich', 'Chicken-Avocado-and-Cheese-Club-Sandwich1.jpg');
INSERT INTO images (`idImages`, `label`, `fileName`) VALUES (55, 'Burger', 'Burgers1.jpg');
INSERT INTO images (`idImages`, `label`, `fileName`) VALUES (56, 'Chicken Fingers', 'applebees_chickenfingers11.jpg');
INSERT INTO images (`idImages`, `label`, `fileName`) VALUES (57, 'Pizza', 'Pizza1.jpg');
INSERT INTO images (`idImages`, `label`, `fileName`) VALUES (58, 'Chicken Quesadilla', 'chicken_quesadilla.jpg');


#
# TABLE STRUCTURE FOR: items
#

DROP TABLE IF EXISTS items;

CREATE TABLE `items` (
  `idItems` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(100) NOT NULL,
  `description` mediumtext,
  `idImage` int(11) DEFAULT NULL,
  `price` varchar(10) DEFAULT NULL,
  `extras` mediumtext,
  `deleted` enum('y','n') NOT NULL DEFAULT 'n',
  PRIMARY KEY (`idItems`),
  KEY `fk_idImages` (`idImage`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COMMENT=' food and beverages items';

INSERT INTO items (`idItems`, `label`, `description`, `idImage`, `price`, `extras`, `deleted`) VALUES (1, 'Food number 1', ' le', 51, '2.99', NULL, 'y');
INSERT INTO items (`idItems`, `label`, `description`, `idImage`, `price`, `extras`, `deleted`) VALUES (9, 'Salad', '', 53, '6.50', NULL, 'n');
INSERT INTO items (`idItems`, `label`, `description`, `idImage`, `price`, `extras`, `deleted`) VALUES (10, 'Chicken Club Sandwich', '', 54, '', NULL, 'n');
INSERT INTO items (`idItems`, `label`, `description`, `idImage`, `price`, `extras`, `deleted`) VALUES (11, 'Burger', '', 55, '5.99', NULL, 'n');
INSERT INTO items (`idItems`, `label`, `description`, `idImage`, `price`, `extras`, `deleted`) VALUES (12, 'Chicken Fingers', '', 56, '', NULL, 'n');
INSERT INTO items (`idItems`, `label`, `description`, `idImage`, `price`, `extras`, `deleted`) VALUES (13, 'Pizza', '', 57, '', NULL, 'n');
INSERT INTO items (`idItems`, `label`, `description`, `idImage`, `price`, `extras`, `deleted`) VALUES (14, 'Chicken Quesadilla', '', 58, '', NULL, 'n');
INSERT INTO items (`idItems`, `label`, `description`, `idImage`, `price`, `extras`, `deleted`) VALUES (2, 'Uno', 'Tre', 0, '2.99', NULL, 'y');
INSERT INTO items (`idItems`, `label`, `description`, `idImage`, `price`, `extras`, `deleted`) VALUES (3, 'due onw', 'ono', 37, '2.99', NULL, 'y');
INSERT INTO items (`idItems`, `label`, `description`, `idImage`, `price`, `extras`, `deleted`) VALUES (4, 'Food number 2', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras ut diam erat, eu volutpat lectus. In at nisi id est tristique lobortis non ac neque. Quisque diam est, tempus commodo tempor hendrerit, cursus in metus. Maecenas nec justo magna. Quisque at risus a lectus vestibulum sagittis. Aliquam consequat neque ut lectus sodales eget pharetra mauris volutpat. Phasellus ac molestie nunc. Vestibulum non lorem eu mi malesuada consectetur. Aenean elit justo, facilisis vitae molestie vitae, commodo ut nunc. Vestibulum non venenatis ipsum. Pellentesque luctus vestibulum odio eget posuere.\r\n\r\nAenean sit amet neque consectetur dolor gravida pharetra in in est. Proin ultricies sem at nulla cursus vitae bibendum orci cursus. Nullam velit nibh, tincidunt ac mattis at, hendrerit sed diam. Cras eu euismod lacus. Donec adipiscing molestie lobortis. Sed sapien lorem, euismod nec volutpat quis, scelerisque nec lacus. Sed varius leo eget mauris feugiat tempor.', 51, '2.99', NULL, 'y');
INSERT INTO items (`idItems`, `label`, `description`, `idImage`, `price`, `extras`, `deleted`) VALUES (5, 'Food number 3', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras ut diam erat, eu volutpat lectus. In at nisi id est tristique lobortis non ac neque. Quisque diam est, tempus commodo tempor hendrerit, cursus in metus. Maecenas nec justo magna. Quisque at risus a lectus vestibulum sagittis. Aliquam consequat neque ut lectus sodales eget pharetra mauris volutpat. Phasellus ac molestie nunc. Vestibulum non lorem eu mi malesuada consectetur. Aenean elit justo, facilisis vitae molestie vitae, commodo ut nunc. Vestibulum non venenatis ipsum. Pellentesque luctus vestibulum odio eget posuere.\r\n\r\nAenean sit amet neque consectetur dolor gravida pharetra in in est. Proin ultricies sem at nulla cursus vitae bibendum orci cursus. Nullam velit nibh, tincidunt ac mattis at, hendrerit sed diam. Cras eu euismod lacus. Donec adipiscing molestie lobortis. Sed sapien lorem, euismod nec volutpat quis, scelerisque nec lacus. Sed varius leo eget mauris feugiat tempor.', 51, '2.99', NULL, 'y');
INSERT INTO items (`idItems`, `label`, `description`, `idImage`, `price`, `extras`, `deleted`) VALUES (6, 'Prova di un nome lungo per un\'item che sto usando per programmare uno due tre quattro', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras ut diam erat, eu volutpat lectus. In at nisi id est tristique lobortis non ac neque. Quisque diam est, tempus commodo tempor hendrerit, cursus in metus. Maecenas nec justo magna. Quisque at risus a lectus vestibulum sagittis. Aliquam consequat neque ut lectus sodales eget pharetra mauris volutpat. Phasellus ac molestie nunc. Vestibulum non lorem eu mi malesuada consectetur. Aenean elit justo, facilisis vitae molestie vitae, commodo ut nunc. Vestibulum non venenatis ipsum. Pellentesque luctus vestibulum odio eget posuere.\r\n\r\nAenean sit amet neque consectetur dolor gravida pharetra in in est. Proin ultricies sem at nulla cursus vitae bibendum orci cursus. Nullam velit nibh, tincidunt ac mattis at, hendrerit sed diam. Cras eu euismod lacus. Donec adipiscing molestie lobortis. Sed sapien lorem, euismod nec volutpat quis, scelerisque nec lacus. Sed varius leo eget mauris feugiat tempor.', 51, '2.99', NULL, 'y');
INSERT INTO items (`idItems`, `label`, `description`, `idImage`, `price`, `extras`, `deleted`) VALUES (7, 'Coca cola', 'Coca cola', 42, '1.00', NULL, 'n');
INSERT INTO items (`idItems`, `label`, `description`, `idImage`, `price`, `extras`, `deleted`) VALUES (8, 'helllllo', '', -1, '5', NULL, 'y');


#
# TABLE STRUCTURE FOR: kqueue
#

DROP TABLE IF EXISTS kqueue;

CREATE TABLE `kqueue` (
  `idKqueue` int(11) NOT NULL AUTO_INCREMENT,
  `sid` varchar(64) NOT NULL,
  `fk_idOrders` int(11) NOT NULL,
  `fk_sid` varchar(64) NOT NULL,
  `status` enum('received','inprogress','checkedout','done') NOT NULL DEFAULT 'received',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`idKqueue`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: menulists
#

DROP TABLE IF EXISTS menulists;

CREATE TABLE `menulists` (
  `idMenulists` int(11) NOT NULL AUTO_INCREMENT,
  `fk_idMenus` int(11) DEFAULT NULL,
  `fk_idCategories` int(11) DEFAULT NULL,
  `fk_idItems` int(11) DEFAULT NULL,
  `price` varchar(10) DEFAULT NULL,
  `categoryPosition` tinyint(4) DEFAULT '0',
  `itemPosition` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`idMenulists`),
  KEY `fk_idMenus` (`fk_idMenus`),
  KEY `fk_idCategories` (`fk_idCategories`),
  KEY `fk_idItems` (`fk_idItems`)
) ENGINE=MyISAM AUTO_INCREMENT=50 DEFAULT CHARSET=utf8;

INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (24, 31, 14, 6, '2.99', 2, 3);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (36, 31, 14, 1, '2.99', 2, 2);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (26, 31, 12, 5, '2.99', 1, 1);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (5, 31, 13, 4, '2.99', 1, 3);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (6, 31, 13, 4, '2.99', 1, 5);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (7, 31, 13, 3, '2.99', 1, 1);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (9, 31, 0, 4, '2.99', 0, 0);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (10, 31, 0, 1, '2.99', 0, 0);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (11, 31, 0, 1, '2.99', 0, 0);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (12, 31, 13, 3, '2.99', 1, 2);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (23, 31, 12, 6, '2.99', 1, 3);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (14, 31, 13, 3, '2.99', 1, 4);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (35, 31, 12, 1, '2.99', 1, 2);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (18, 30, 12, 6, '2.99', 2, 1);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (28, 31, 14, 4, '2.99', 2, 1);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (30, 31, 14, 4, '2.99', 2, 4);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (33, 31, 14, 6, '2.99', 2, 5);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (39, 30, 14, 7, '1.00', 0, 0);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (38, 30, 12, 4, '2.99', 2, 2);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (37, 30, 14, 5, '2.99', 1, 1);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (45, 35, 14, 1, '2.99', 0, 0);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (41, 32, 12, 1, '2.99', 0, 0);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (42, 32, 14, 7, '1.00', 0, 0);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (43, 31, 15, 1, '2.99', 0, 0);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (46, 35, 12, 4, '2.99', 0, 0);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (47, 35, 15, 5, '2.99', 0, 0);
INSERT INTO menulists (`idMenulists`, `fk_idMenus`, `fk_idCategories`, `fk_idItems`, `price`, `categoryPosition`, `itemPosition`) VALUES (49, 35, 15, 6, '2.99', 0, 0);


#
# TABLE STRUCTURE FOR: menus
#

DROP TABLE IF EXISTS menus;

CREATE TABLE `menus` (
  `idMenus` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(45) NOT NULL,
  `description` tinytext,
  `idImage` int(11) NOT NULL DEFAULT '0',
  `extras` mediumtext,
  `price` tinytext,
  `visible` varchar(10) DEFAULT NULL,
  `menuType` enum('f','c') DEFAULT 'c',
  `foodbev` enum('f','b') DEFAULT 'f',
  `position` tinyint(4) DEFAULT NULL,
  `deleted` enum('y','n') NOT NULL DEFAULT 'n',
  PRIMARY KEY (`idMenus`),
  UNIQUE KEY `label_UNIQUE` (`label`),
  KEY `fk_idImages` (`idImage`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COMMENT='A la carte, Vegetarian, early birds etc...';

INSERT INTO menus (`idMenus`, `label`, `description`, `idImage`, `extras`, `price`, `visible`, `menuType`, `foodbev`, `position`, `deleted`) VALUES (27, 'AhAH', '', 0, NULL, NULL, 'y', 'f', 'f', NULL, 'y');
INSERT INTO menus (`idMenus`, `label`, `description`, `idImage`, `extras`, `price`, `visible`, `menuType`, `foodbev`, `position`, `deleted`) VALUES (26, 'testmenu', '', 0, NULL, NULL, 'y', 'f', 'f', NULL, 'y');
INSERT INTO menus (`idMenus`, `label`, `description`, `idImage`, `extras`, `price`, `visible`, `menuType`, `foodbev`, `position`, `deleted`) VALUES (17, 'Food menu', 'Test Food menu', 0, NULL, NULL, 'y', 'f', 'f', NULL, 'y');
INSERT INTO menus (`idMenus`, `label`, `description`, `idImage`, `extras`, `price`, `visible`, `menuType`, `foodbev`, `position`, `deleted`) VALUES (32, 'Menu of the day', '', 0, NULL, NULL, 'y', 'c', 'f', 2, 'y');
INSERT INTO menus (`idMenus`, `label`, `description`, `idImage`, `extras`, `price`, `visible`, `menuType`, `foodbev`, `position`, `deleted`) VALUES (31, 'Grill menu', '', 0, NULL, NULL, 'y', 'c', 'f', 1, 'n');
INSERT INTO menus (`idMenus`, `label`, `description`, `idImage`, `extras`, `price`, `visible`, `menuType`, `foodbev`, `position`, `deleted`) VALUES (28, 'ahahah', '', 0, NULL, NULL, 'y', 'f', 'f', NULL, 'y');
INSERT INTO menus (`idMenus`, `label`, `description`, `idImage`, `extras`, `price`, `visible`, `menuType`, `foodbev`, `position`, `deleted`) VALUES (29, 'Wine List', 'bla', 0, NULL, NULL, 'y', 'c', 'b', 2, 'y');
INSERT INTO menus (`idMenus`, `label`, `description`, `idImage`, `extras`, `price`, `visible`, `menuType`, `foodbev`, `position`, `deleted`) VALUES (30, 'Drinks', '', 0, NULL, NULL, 'y', 'c', 'b', 1, 'n');
INSERT INTO menus (`idMenus`, `label`, `description`, `idImage`, `extras`, `price`, `visible`, `menuType`, `foodbev`, `position`, `deleted`) VALUES (33, 'test', '', 0, NULL, NULL, 'y', 'f', 'f', NULL, 'y');
INSERT INTO menus (`idMenus`, `label`, `description`, `idImage`, `extras`, `price`, `visible`, `menuType`, `foodbev`, `position`, `deleted`) VALUES (34, 'Menu prova', '', 0, NULL, NULL, 'y', 'c', 'f', 3, 'y');
INSERT INTO menus (`idMenus`, `label`, `description`, `idImage`, `extras`, `price`, `visible`, `menuType`, `foodbev`, `position`, `deleted`) VALUES (35, 'Demo Menu', '', 0, NULL, NULL, 'y', 'c', 'f', 2, 'n');


#
# TABLE STRUCTURE FOR: modules
#

DROP TABLE IF EXISTS modules;

CREATE TABLE `modules` (
  `idModules` int(11) NOT NULL,
  `label` varchar(100) NOT NULL,
  PRIMARY KEY (`idModules`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO modules (`idModules`, `label`) VALUES (0, 'admin');
INSERT INTO modules (`idModules`, `label`) VALUES (1, 'menuconf');
INSERT INTO modules (`idModules`, `label`) VALUES (2, 'orders');
INSERT INTO modules (`idModules`, `label`) VALUES (3, 'kitchen');
INSERT INTO modules (`idModules`, `label`) VALUES (4, 'bar');


#
# TABLE STRUCTURE FOR: orders
#

DROP TABLE IF EXISTS orders;

CREATE TABLE `orders` (
  `idOrders` int(11) NOT NULL AUTO_INCREMENT,
  `fk_sid` varchar(45) NOT NULL,
  `fk_idMenulists` int(11) DEFAULT NULL,
  `number` smallint(6) DEFAULT NULL,
  `note` mediumtext NOT NULL,
  `ksent` enum('y','n') NOT NULL DEFAULT 'n',
  `status` enum('received','inprogress','done') NOT NULL DEFAULT 'received',
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`idOrders`),
  KEY `fk_idMenulists` (`fk_idMenulists`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (1, '144ff89a03899b6265a15bde4db72213', 47, 1, '', 'y', 'received', '2014-03-16 01:58:19');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (2, '144ff89a03899b6265a15bde4db72213', 45, 1, 'hoooooooooot', 'y', 'received', '2014-03-16 01:58:28');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (3, '8abfd7b0bdebc4c58bec4fa1bef7f98e', 43, 1, '', 'y', 'received', '2014-03-27 21:35:27');
INSERT INTO orders (`idOrders`, `fk_sid`, `fk_idMenulists`, `number`, `note`, `ksent`, `status`, `timestamp`) VALUES (4, '8abfd7b0bdebc4c58bec4fa1bef7f98e', 26, 1, 'make it hot', 'y', 'received', '2014-03-27 21:35:46');


#
# TABLE STRUCTURE FOR: permissions
#

DROP TABLE IF EXISTS permissions;

CREATE TABLE `permissions` (
  `fk_idModules` int(11) NOT NULL,
  `fk_idRoles` int(11) NOT NULL,
  KEY `fk_idRoles` (`fk_idRoles`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (1, 0);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (2, 0);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (0, 0);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (3, 0);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (4, 0);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (2, 2);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (1, 1);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (2, 1);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (3, 1);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (4, 1);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (3, 2);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (4, 2);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (3, 3);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (4, 3);
INSERT INTO permissions (`fk_idModules`, `fk_idRoles`) VALUES (4, 4);


#
# TABLE STRUCTURE FOR: roles
#

DROP TABLE IF EXISTS roles;

CREATE TABLE `roles` (
  `idRoles` int(11) NOT NULL,
  `label` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idRoles`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO roles (`idRoles`, `label`) VALUES (0, 'admin');
INSERT INTO roles (`idRoles`, `label`) VALUES (1, 'supervisor');
INSERT INTO roles (`idRoles`, `label`) VALUES (2, 'staff manager');
INSERT INTO roles (`idRoles`, `label`) VALUES (3, 'cook');
INSERT INTO roles (`idRoles`, `label`) VALUES (4, 'waiter');


#
# TABLE STRUCTURE FOR: sessions
#

DROP TABLE IF EXISTS sessions;

CREATE TABLE `sessions` (
  `idSessions` int(11) NOT NULL AUTO_INCREMENT,
  `sid` varchar(45) DEFAULT NULL,
  `fk_idTables` int(11) DEFAULT NULL,
  `extras` mediumtext,
  `ticket` mediumtext NOT NULL,
  `bell` enum('y','n') DEFAULT 'n',
  `suspended` enum('y','n') DEFAULT 'n',
  `status` enum('insession','checkedout') NOT NULL DEFAULT 'insession',
  PRIMARY KEY (`idSessions`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (1, 'eb1ef2118d67fb5c952d28639bc0c69f', NULL, '{\"mininterval\":\"60000\",\"maxitems\":\"0\",\"maxrounds\":\"0\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '', 'n', 'n', 'insession');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (2, 'fa69967a3ce752135afd305546b3a6d8', NULL, '{\"mininterval\":\"60000\",\"maxitems\":\"0\",\"maxrounds\":\"0\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '', 'n', 'n', 'insession');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (3, 'fa72880811db61c996b27979afb627c4', 1, '{\"mininterval\":\"60000\",\"maxitems\":\"0\",\"maxrounds\":\"0\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '{\"total\":0,\"fixed\":{\"adultsnr\":null,\"childrennr\":null,\"adults\":0,\"children\":0},\"carte\":[]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (4, '144ff89a03899b6265a15bde4db72213', 24, '{\"mininterval\":\"60000\",\"maxitems\":\"0\",\"maxrounds\":\"0\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '{\"total\":5.98,\"fixed\":{\"adultsnr\":null,\"childrennr\":null,\"adults\":0,\"children\":0},\"carte\":[{\"label\":\"Food number 1\",\"idMenulists\":\"45\",\"idOrders\":\"2\",\"price\":2.99,\"number\":\"1\"},{\"label\":\"Food number 3\",\"idMenulists\":\"47\",\"idOrders\":\"1\",\"price\":2.99,\"number\":\"1\"}]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (5, 'd99133920ad7e9d345c3207c76578db8', 21, '{\"mininterval\":\"60000\",\"maxitems\":\"0\",\"maxrounds\":\"0\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '', 'y', 'n', 'insession');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (6, '0f6aa02718133c479826102cda2ab925', 1, '{\"mininterval\":\"60000\",\"maxitems\":\"0\",\"maxrounds\":\"0\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '{\"total\":0,\"fixed\":{\"adultsnr\":null,\"childrennr\":null,\"adults\":0,\"children\":0},\"carte\":[]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (7, 'e00716ea3f1f0c9516913c12746e297d', 24, '{\"mininterval\":\"60000\",\"maxitems\":\"0\",\"maxrounds\":\"0\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '{\"total\":0,\"fixed\":{\"adultsnr\":null,\"childrennr\":null,\"adults\":0,\"children\":0},\"carte\":[]}', 'n', 'n', 'insession');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (8, '8af44c82d42b3da0f6b6636a05612633', 19, '{\"mininterval\":\"60000\",\"maxitems\":\"0\",\"maxrounds\":\"0\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '', 'n', 'n', 'insession');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (9, '21b89aa7d72c98934e924d272266c1f5', 3, '{\"mininterval\":\"60000\",\"maxitems\":\"0\",\"maxrounds\":\"0\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '', 'n', 'n', 'insession');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (10, '70377e0b262b03f2c13e14ddf2f37d07', 25, '{\"mininterval\":\"60000\",\"maxitems\":\"0\",\"maxrounds\":\"0\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '{\"total\":0,\"fixed\":{\"adultsnr\":null,\"childrennr\":null,\"adults\":0,\"children\":0},\"carte\":[]}', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (11, '3c272ca39870756a12adb21e51c14a3d', 25, '{\"mininterval\":\"60000\",\"maxitems\":\"0\",\"maxrounds\":\"0\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '', 'n', 'n', 'checkedout');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (12, 'd484c1776e760193641c2ef05038d2aa', 25, '{\"mininterval\":\"60000\",\"maxitems\":\"0\",\"maxrounds\":\"0\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '', 'n', 'n', 'insession');
INSERT INTO sessions (`idSessions`, `sid`, `fk_idTables`, `extras`, `ticket`, `bell`, `suspended`, `status`) VALUES (13, '8abfd7b0bdebc4c58bec4fa1bef7f98e', 1, '{\"mininterval\":\"60000\",\"maxitems\":\"0\",\"maxrounds\":\"0\",\"currentroundts\":\"0\",\"currentround\":\"0\",\"currentitems\":\"0\"}', '{\"total\":5.98,\"fixed\":{\"adultsnr\":null,\"childrennr\":null,\"adults\":0,\"children\":0},\"carte\":[{\"label\":\"Food number 3\",\"idMenulists\":\"26\",\"idOrders\":\"4\",\"price\":2.99,\"number\":\"1\"},{\"label\":\"Food number 1\",\"idMenulists\":\"43\",\"idOrders\":\"3\",\"price\":2.99,\"number\":\"1\"}]}', 'n', 'n', 'checkedout');


#
# TABLE STRUCTURE FOR: tables
#

DROP TABLE IF EXISTS tables;

CREATE TABLE `tables` (
  `idTables` int(11) NOT NULL AUTO_INCREMENT,
  `tableName` varchar(45) NOT NULL,
  PRIMARY KEY (`idTables`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;

INSERT INTO tables (`idTables`, `tableName`) VALUES (28, 'Table 3');
INSERT INTO tables (`idTables`, `tableName`) VALUES (35, 'Table 10');
INSERT INTO tables (`idTables`, `tableName`) VALUES (34, 'Table 9');
INSERT INTO tables (`idTables`, `tableName`) VALUES (33, 'Table 8');
INSERT INTO tables (`idTables`, `tableName`) VALUES (32, 'Table 7');
INSERT INTO tables (`idTables`, `tableName`) VALUES (31, 'Table 6');
INSERT INTO tables (`idTables`, `tableName`) VALUES (27, 'Table 2');
INSERT INTO tables (`idTables`, `tableName`) VALUES (26, 'Table 1');
INSERT INTO tables (`idTables`, `tableName`) VALUES (29, 'Table 4');
INSERT INTO tables (`idTables`, `tableName`) VALUES (30, 'Table 5');


#
# TABLE STRUCTURE FOR: tickets
#

DROP TABLE IF EXISTS tickets;

CREATE TABLE `tickets` (
  `idTickets` int(11) NOT NULL AUTO_INCREMENT,
  `fk_sid` varchar(64) NOT NULL,
  `ticket` mediumtext NOT NULL,
  PRIMARY KEY (`idTickets`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO tickets (`idTickets`, `fk_sid`, `ticket`) VALUES (4, '70377e0b262b03f2c13e14ddf2f37d07', '{\"total\":0,\"fixed\":{\"adultsnr\":null,\"childrennr\":null,\"adults\":0,\"children\":0},\"carte\":[]}');
INSERT INTO tickets (`idTickets`, `fk_sid`, `ticket`) VALUES (5, '3c272ca39870756a12adb21e51c14a3d', '');
INSERT INTO tickets (`idTickets`, `fk_sid`, `ticket`) VALUES (6, '8abfd7b0bdebc4c58bec4fa1bef7f98e', '{\"total\":5.98,\"fixed\":{\"adultsnr\":null,\"childrennr\":null,\"adults\":0,\"children\":0},\"carte\":[{\"label\":\"Food number 3\",\"idMenulists\":\"26\",\"idOrders\":\"4\",\"price\":2.99,\"number\":\"1\"},{\"label\":\"Food number 1\",\"idMenulists\":\"43\",\"idOrders\":\"3\",\"price\":2.99,\"number\":\"1\"}]}');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS users;

CREATE TABLE `users` (
  `idUsers` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(25) NOT NULL,
  `lastName` varchar(25) NOT NULL,
  `emailAddress` varchar(50) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(32) NOT NULL,
  `role` tinyint(4) NOT NULL,
  PRIMARY KEY (`idUsers`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO users (`idUsers`, `firstName`, `lastName`, `emailAddress`, `username`, `password`, `role`) VALUES (0, '', '', '', 'admin', '098f6bcd4621d373cade4e832627b4f6', 0);
INSERT INTO users (`idUsers`, `firstName`, `lastName`, `emailAddress`, `username`, `password`, `role`) VALUES (2, 'Mario', 'Rossi', '', 'manager', '098f6bcd4621d373cade4e832627b4f6', 2);
INSERT INTO users (`idUsers`, `firstName`, `lastName`, `emailAddress`, `username`, `password`, `role`) VALUES (1, 'Gino', 'Bianchi', '', 'supervisor', 'c4ca4238a0b923820dcc509a6f75849b', 1);
INSERT INTO users (`idUsers`, `firstName`, `lastName`, `emailAddress`, `username`, `password`, `role`) VALUES (3, 'Paolo', 'Verdi', '', 'cook', '098f6bcd4621d373cade4e832627b4f6', 3);
INSERT INTO users (`idUsers`, `firstName`, `lastName`, `emailAddress`, `username`, `password`, `role`) VALUES (4, 'John', 'Waiter', '', 'waiter', '098f6bcd4621d373cade4e832627b4f6', 4);
INSERT INTO users (`idUsers`, `firstName`, `lastName`, `emailAddress`, `username`, `password`, `role`) VALUES (9, '', '', '', 'amgad', 'c4ca4238a0b923820dcc509a6f75849b', 0);


